LAB 10 RESOURCES

1. Unzip this package and open touchsensor/touchsensor.ino in Arduino IDE.
   Select Arduino Leonardo and the matching port. Use USB power.
   Install the Keyboard library by Arduino if the IDE reports it missing.
2. Keep NUM_CHANNELS at 1 and KEYBOARD_ON false for this lab.
   tauThreshold starts at 1000000.0f as a calibration placeholder.
3. Each group must record untouched and touched ranges at 115200 baud,
   calculate a threshold between the ranges, edit tauThreshold and upload.
   The Word manual provides the procedure and blank observation tables.
4. Demonstrate LED on when touched and off when released. Save calibration
   readings and the edited sketch as evidence. Recalibrate after wiring changes.

Task 2 pin mapping
D10: charging output through R2 = 100 kOhm to D0
D0: sensing node, connected directly to the wire loop
D9: through R3 = 330 Ohm to LED anode; LED cathode to GND
The fixed 100 nF capacitor is used only in Task 1.

The sketch adapts the supplied MIT RP2040 code to Arduino Leonardo. It uses
an approximately 100 Hz square wave and direct charging-delay timing.
Serial readings are approximate time constants in microseconds, using the
original 1.44 multiplier. They are not 10-to-90% rise times or calibrated RC
measurements. Actual digital input thresholds and software timing add error.
A reading of -1 indicates timeout or failure to discharge. Check the circuit
if errors persist; do not include error readings in the calibration table.

Timer1 is reserved for timing. Do not add Servo or analogWrite on D9/D10.
USB Serial is used; do not use Serial1 on sensing pins D0/D1.
The code also retains the original five-pad and optional keyboard modes,
but these extensions are not required for Lab 11.

Both single-loop mode and five-pad mode with keyboard output were compiled
for Arduino Leonardo. Physical testing and student calibration are required.

The circuits folder contains editable CircuitikZ .tex files, vector PDFs and
high resolution PNGs. Compile each .tex file using pdflatex or Overleaf.

References
https://circuits.mit.edu/F26/labs/rc
https://circuits.mit.edu/F26/psets/04/prelab
https://docs.arduino.cc/hardware/leonardo/
